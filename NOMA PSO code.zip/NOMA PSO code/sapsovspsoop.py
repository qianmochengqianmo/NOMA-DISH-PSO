import math
import numpy as np
import matplotlib.pyplot as plt


def initialize_parameters_fixed(M, lam1_dB):
    mSD1 = int(5)
    bSD1 = 0.251
    omegaSD1 = 0.278
    alphaSD1 = ((2 * bSD1 * mSD1) / (2 * bSD1 * mSD1 + omegaSD1)) ** mSD1 / (2 * bSD1)
    betaSD1 = 1 / (2 * bSD1)
    deltaSD1 = omegaSD1 / (2 * bSD1 * (2 * bSD1 * mSD1 + omegaSD1))
    BSD1 = betaSD1 - deltaSD1
    kai11 = 0.5
    V11 = 0.001
    ks = 0.1
    kD1 = 0.1
    HI = ks ** 2 + kD1 ** 2
    Xi = 0.01
    lam1 = 10 ** (lam1_dB / 10)
    eta = 0.8
    return mSD1, alphaSD1, BSD1, lam1, deltaSD1, M, kai11, V11, HI, Xi, eta

def Pochhammer(s, k):
    result = 1
    for i in range(k):
        result *= (s + i)
    return result

def Theta(k, deltaSD1, mSD1):
    if k == 0:
        return 1
    return ((-1) ** k * Pochhammer(1 - mSD1, k) * deltaSD1 ** k) / (math.factorial(k) ** 2)

def Ap(M, gammath, kai11, V11, lam1, HI, Xi, p, a):
    if p == 1:
        num = gammath * kai11 * V11 * lam1 * (1 + HI) + gammath
        den = kai11 * lam1 * (a[p - 1] - gammath * np.sum(a[1:]) - gammath * HI)
    else:
        num = gammath * kai11 * V11 * lam1 * (Xi * np.sum(a[:p - 1]) + np.sum(a[p:]) + a[p - 1] + HI) + gammath
        den = kai11 * lam1 * (a[p - 1] - gammath * (Xi * np.sum(a[:p - 1]) + np.sum(a[p:])) - gammath * HI)
    return num / den

def P(alphaSD1, mSD1, BSD1, p, a, Ap_value, deltaSD1):
    user_OP_sum = 0
    for k in range(mSD1):
        theta = Theta(k, deltaSD1, mSD1)
        safe_input = np.clip(-Ap_value * BSD1, -700, 700)
        exp_term = np.exp(safe_input)
        factorial_k = math.factorial(k)
        first_term = factorial_k / (BSD1 ** (k + 1))
        second_term_sum = sum((factorial_k / math.factorial(n)) * (Ap_value ** n) / (BSD1 ** (k - n + 1)) for n in range(k + 1))
        user_OP = theta * (first_term - exp_term * second_term_sum)
        user_OP_sum += user_OP
    result = alphaSD1 * user_OP_sum
    return min(max(result, 0), 1)

def gammath_for_user(p, eta):
    if p == 1:
        return 1
    return eta * gammath_for_user(p - 1, eta)

def fitness_func_fixed(a, *args):
    M, alphaSD1, mSD1, BSD1, lam1, deltaSD1, kai11, V11, HI, Xi, eta = args
    mSD1 = int(mSD1)
    total_OP = 1
    for p in range(1, M + 1):
        gammath_p = gammath_for_user(p, eta)
        try:
            Ap_value = Ap(M, gammath_p, kai11, V11, lam1, HI, Xi, p, a)
            Pp = P(alphaSD1, mSD1, BSD1, p, a, Ap_value, deltaSD1)
            total_OP *= max(1 - Pp, 1e-12)
        except Exception:
            return 1
    if not np.isfinite(total_OP) or total_OP < 0 or total_OP > 1:
        return 1
    return 1 - total_OP

def apply_constraints(particles, dimensions, Xi, HI, eta):
    gammath1 = gammath_for_user(1, eta)
    for i in range(particles.shape[0]):
        tries = 0
        while True:
            tries += 1
            valid = True
            if tries > 1000:
                break
            particles[i, :] = np.random.dirichlet(np.ones(dimensions), size=1)[0]
            particles[i, :] = np.sort(particles[i, :])[::-1]
            sum_a_i = np.sum(particles[i, 1:])
            if particles[i, 0] <= (sum_a_i + HI) * gammath1:
                valid = False
            for p in range(1, dimensions + 1):
                sum_before_p = np.sum(particles[i, :p - 1]) if p >= 2 else 0
                sum_after_p = np.sum(particles[i, p:]) if p < dimensions else 0
                if particles[i, p - 1] <= (Xi * sum_before_p + sum_after_p + HI) * gammath_for_user(p, eta):
                    valid = False
                    break
            if valid:
                break
    return particles

def pso(fitness_func, bounds, num_particles, max_iter, method, *args):
    dim = len(bounds)
    particles = np.random.uniform(bounds[:, 0], bounds[:, 1], (num_particles, dim))
    velocities = np.zeros((num_particles, dim))
    pbest_positions = particles.copy()
    particles = apply_constraints(particles, dim, args[9], args[8], args[10])
    pbest_values = np.array([fitness_func(p, *args) for p in particles])
    gbest_idx = np.argmin(pbest_values)
    gbest_position = particles[gbest_idx].copy()
    gbest_value = pbest_values[gbest_idx]
    w_start = 0.9
    w_end = 0.3

    for current_iter in range(max_iter):
        # w = w_start - (w_start - w_end) * (current_iter / max_iter) if method == 'SA-PSO' else 0.9
        w = w_end + (w_start - w_end) * np.exp(-5 * current_iter / max_iter) if method == 'SA-PSO' else 0.9
        for i in range(num_particles):
            r1, r2 = np.random.rand(2)
            velocities[i] = w * velocities[i] + 2.05 * r1 * (pbest_positions[i] - particles[i]) + 2.05 * r2 * (gbest_position - particles[i])
            particles[i] += velocities[i]
            particles = apply_constraints(particles, dim, args[9], args[8], args[10])
            val = fitness_func(particles[i], *args)
            if val < pbest_values[i]:
                pbest_positions[i] = particles[i].copy()
                pbest_values[i] = val
                if val < gbest_value:
                    gbest_position = particles[i].copy()
                    gbest_value = val
    return gbest_value

# --- 主程序 ---
snr_dBs = [5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55]
user_counts = [5, 6, 7]
results = {
    "SNR (dB)": snr_dBs
}
for M in user_counts:
    results[f"SA-PSO M={M}"] = []
    results[f"PSO M={M}"] = []

for M in user_counts:
    for snr_db in snr_dBs:
        params = initialize_parameters_fixed(M, snr_db)
        bounds = np.array([(0, 1) for _ in range(M)])
        val_sa = pso(fitness_func_fixed, bounds, 20, 30, 'SA-PSO', *params)
        val_pso = pso(fitness_func_fixed, bounds, 20, 30, 'PSO', *params)
        results[f"SA-PSO M={M}"].append(val_sa)
        results[f"PSO M={M}"].append(val_pso)

# 转换为DataFrame
# -------------------------------
# 不使用 pandas 的结果输出部分
# -------------------------------
print("\n=== SA-PSO vs PSO Best Value Table ===")
print("{:<10}".format("SNR(dB)"), end="")
for M in user_counts:
    print(f"  SA-M={M:<4}  PSO-M={M:<4}", end="")
print()

for i in range(len(snr_dBs)):
    print("{:<10}".format(snr_dBs[i]), end="")
    for M in user_counts:
        sa_val = results[f"SA-PSO M={M}"][i]
        pso_val = results[f"PSO M={M}"][i]
        print(f"{sa_val:<10.4f}  {pso_val:<10.4f}", end="")
    print()

# -------------------------------
# 不使用 pandas 的绘图部分
# -------------------------------
plt.figure(figsize=(10, 6))
markers = ['o', 's', '^']

for idx, M in enumerate(user_counts):
    sa_vals = results[f"SA-PSO M={M}"]
    pso_vals = results[f"PSO M={M}"]
    plt.plot(snr_dBs, sa_vals, marker=markers[idx], label=f'SA-PSO (M={M})')
    plt.plot(snr_dBs, pso_vals, marker=markers[idx], linestyle='--', label=f'PSO (M={M})')

plt.xlabel('SNR (dB)', fontsize=12)
plt.ylabel('Best Value (Outage Probability)', fontsize=12)
plt.title('SA-PSO vs PSO Optimization for M=6,8,10', fontsize=14)
plt.grid(True)
plt.legend(fontsize=11)
plt.tight_layout()
plt.show()


# 打印输出结果表格
print("\n=== SA-PSO vs PSO Best Value Table ===")
print("SNR (dB):", snr_dBs)
for M in user_counts:
    print(f"SA-PSO (M={M}):", results[f"SA-PSO M={M}"])
    print(f"PSO    (M={M}):", results[f"PSO M={M}"])

