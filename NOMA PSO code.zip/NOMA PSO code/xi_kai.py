# === PSO 优化中断概率分析代码（可调参数，修复超时问题 + 支持动态M）===

import math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# 初始化参数（支持变量输入）
def initialize_parameters(mSD1, bSD1, omegaSD1, kai11, V11, ks, kD1, Xi, lam1_dB, M, eta):
    alphaSD1 = ((2 * bSD1 * mSD1) / (2 * bSD1 * mSD1 + omegaSD1)) ** mSD1 / (2 * bSD1)
    betaSD1 = 1 / (2 * bSD1)
    deltaSD1 = omegaSD1 / (2 * bSD1 * (2 * bSD1 * mSD1 + omegaSD1))
    BSD1 = betaSD1 - deltaSD1
    HI = ks ** 2 + kD1 ** 2
    lam1 = 10 ** (lam1_dB / 10)
    return mSD1, alphaSD1, BSD1, lam1, deltaSD1, M, kai11, V11, HI, Xi, eta

def Pochhammer(s, k):
    result = 1
    for i in range(k):
        result *= (s + i)
    return result

def Theta(k, deltaSD1, mSD1):
    if k == 0:
        return 1
    return ((-1) ** k * Pochhammer(1 - mSD1, k) * deltaSD1 ** k) / (math.factorial(k) ** 2)

def Ap(M, gammath, kai11, V11, lam1, HI, Xi, p, a):
    if len(a) < p:
        raise IndexError(f"Index p={p} out of bounds for power vector of length {len(a)}")
    if p == 1:
        num = gammath * kai11 * V11 * lam1 * (1 + HI) + gammath
        den = kai11 * lam1 * (a[0] - gammath * np.sum(a[1:]) - gammath * HI)
    else:
        num = gammath * kai11 * V11 * lam1 * (Xi * np.sum(a[:p - 1]) + np.sum(a[p:]) + a[p - 1] + HI) + gammath
        den = kai11 * lam1 * (a[p - 1] - gammath * (Xi * np.sum(a[:p - 1]) + np.sum(a[p:])) - gammath * HI)
    return num / den

def P(alphaSD1, mSD1, BSD1, p, a, Ap_value, deltaSD1):
    user_OP_sum = 0
    for k in range(int(mSD1)):
        theta = Theta(k, deltaSD1, mSD1)
        exp_term = np.exp(-Ap_value * BSD1)
        factorial_k = math.factorial(k)
        first_term = factorial_k / (BSD1 ** (k + 1))
        second_term_sum = 0
        for n in range(k + 1):
            second_term_sum += (factorial_k / math.factorial(n)) * (Ap_value ** n) / (BSD1 ** (k - n + 1))
        user_OP = theta * (first_term - exp_term * second_term_sum)
        user_OP_sum += user_OP
    return alphaSD1 * user_OP_sum

def gammath_for_user(p, eta):
    return eta ** (p - 1)

def fitness_func(a, *args):
    M, alphaSD1, mSD1, BSD1, lam1, deltaSD1, kai11, V11, HI, Xi, eta = args
    total_OP = 1
    for p in range(1, M + 1):
        gammath_p = gammath_for_user(p, eta)
        Ap_value = Ap(M, gammath_p, kai11, V11, lam1, HI, Xi, p, a)
        Pp = P(alphaSD1, mSD1, BSD1, p, a, Ap_value, deltaSD1)
        total_OP *= (1 - Pp)
    return 1 - total_OP, None

def apply_constraints(particles, dimensions, Xi, HI, eta, max_attempts=1000):
    particles = np.array(particles)
    gammath1 = gammath_for_user(1, eta)
    for i in range(particles.shape[0]):
        attempt = 0
        while attempt < max_attempts:
            attempt += 1
            valid = True
            particles[i, :] = np.sort(np.random.dirichlet(np.ones(dimensions)))[::-1]
            if particles[i, 0] <= (np.sum(particles[i, 1:]) + HI) * gammath1:
                continue
            for p in range(1, dimensions + 1):
                sum_before = np.sum(particles[i, :p - 1]) if p > 1 else 0
                sum_after = np.sum(particles[i, p:]) if p < dimensions else 0
                if particles[i, p - 1] <= (Xi * sum_before + sum_after + HI) * gammath_for_user(p, eta):
                    valid = False
                    break
            if valid:
                break
    return particles

def pso(fitness_func, bounds, num_particles, max_iter, *args):
    dim = len(bounds)
    particles = np.random.uniform(bounds[:, 0], bounds[:, 1], (num_particles, dim))
    velocities = np.zeros((num_particles, dim))
    particles = apply_constraints(particles, dim, args[9], args[8], args[10])
    pbest_positions = particles.copy()
    pbest_values = [fitness_func(p, *args)[0] for p in particles]
    gbest_value = min(pbest_values)
    gbest_position = particles[np.argmin(pbest_values)]
    w_start, w_end = 0.9, 0.3
    for t in range(max_iter):
        w = w_start - (w_start - w_end) * (t / max_iter)
        for i in range(num_particles):
            r1, r2 = np.random.rand(2)
            velocities[i] = w * velocities[i] + 2.05 * r1 * (pbest_positions[i] - particles[i]) + 2.05 * r2 * (gbest_position - particles[i])
            particles[i] += velocities[i]
            particles[i:i+1] = apply_constraints(particles[i:i+1], dim, args[9], args[8], args[10])
            fit = fitness_func(particles[i], *args)[0]
            if fit < pbest_values[i]:
                pbest_positions[i] = particles[i].copy()
                pbest_values[i] = fit
                if fit < gbest_value:
                    gbest_value = fit
                    gbest_position = particles[i].copy()
    return gbest_value

# ======================== 主函数：运行仿真并画图 ==========================
if __name__ == "__main__":
    from scipy.io import savemat

    # 固定参数
    mSD1 = 5
    bSD1 = 0.251
    omegaSD1 = 0.278
    M = 3
    eta = 0.6
    lam1_dB_values = np.linspace(5, 65, 13)

    # 此轮固定 ks 和 V11，变化 kai11 与 Xi
    ks = 0.01
    V11 = 0.001

    kai11_values = [0.01, 0.1, 1.0]
    Xi_values = [0.01, 0.05, 0.1]

    results_xi_kai = {}

    for kai11 in kai11_values:
        for Xi in Xi_values:
            kD1 = ks
            label = f"kai_{str(kai11).replace('.', '_')}_Xi_{str(Xi).replace('.', '_')}"
            outage_data = []
            for lam1_dB in lam1_dB_values:
                init_args = initialize_parameters(mSD1, bSD1, omegaSD1, kai11, V11, ks, kD1, Xi, lam1_dB, M, eta)
                args = (
                    int(init_args[5]),   # M
                    float(init_args[1]), # alphaSD1
                    int(init_args[0]),   # mSD1
                    float(init_args[2]), # BSD1
                    float(init_args[3]), # lam1
                    float(init_args[4]), # deltaSD1
                    float(init_args[6]), # kai11
                    float(init_args[7]), # V11
                    float(init_args[8]), # HI
                    float(init_args[9]), # Xi
                    float(init_args[10]) # eta
                )
                bounds = np.array([(0, 1)] * M)
                outage = pso(fitness_func, bounds, 30, 50, *args)
                outage_data.append(outage)
            results_xi_kai[label] = outage_data

    # 绘图：所有曲线在同一张图中
    plt.figure(figsize=(8, 6))
    for label, outage in results_xi_kai.items():
        plt.plot(lam1_dB_values, outage, marker='o', label=label)
    plt.title("Outage Probability vs. SNR for Different Xi and kai11")
    plt.xlabel("SNR (dB)")
    plt.ylabel("Outage Probability")
    plt.grid(True)
    plt.legend(fontsize=8)
    plt.tight_layout()
    plt.show()

    # 保存为MAT文件（Xi与kai组合结果）
    export_data = {"SNR_dB": lam1_dB_values}
    export_data.update(results_xi_kai)
    savemat("outage_Xi_kai.mat", export_data)
