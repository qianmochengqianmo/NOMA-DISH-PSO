import math
import numpy as np
import matplotlib.pyplot as plt
import sys
print(sys.executable)


def initialize_parameters_fixed(M, lam1_dB):
    mSD1 = int(5)
    bSD1 = 0.251
    omegaSD1 = 0.278
    alphaSD1 = ((2 * bSD1 * mSD1) / (2 * bSD1 * mSD1 + omegaSD1)) ** mSD1 / (2 * bSD1)
    betaSD1 = 1 / (2 * bSD1)
    deltaSD1 = omegaSD1 / (2 * bSD1 * (2 * bSD1 * mSD1 + omegaSD1))
    BSD1 = betaSD1 - deltaSD1
    kai11 = 0.5
    V11 = 0.001
    ks = 0.1
    kD1 = 0.1
    HI = ks ** 2 + kD1 ** 2
    Xi = 0.01
    lam1 = 10 ** (lam1_dB / 10)
    eta = 0.8
    return mSD1, alphaSD1, BSD1, lam1, deltaSD1, kai11, V11, HI, Xi, eta

def Pochhammer(s, k):
    result = 1
    for i in range(k):
        result *= (s + i)
    return result

def Theta(k, deltaSD1, mSD1):
    if k == 0:
        return 1
    return ((-1) ** k * Pochhammer(1 - mSD1, k) * deltaSD1 ** k) / (math.factorial(k) ** 2)

def Ap(M, gammath, kai11, V11, lam1, HI, Xi, p, a):
    sum_before = np.sum(a[:p - 1])  # safe: a[:0] is empty if p=1
    sum_after = np.sum(a[p:]) if p < M else 0  # avoid a[p] when p=M

    if p == 1:
        num = gammath * kai11 * V11 * lam1 * (1 + HI) + gammath
        den = kai11 * lam1 * (a[p - 1] - gammath * np.sum(a[1:]) - gammath * HI)
    else:
        num = gammath * kai11 * V11 * lam1 * (Xi * sum_before + sum_after + a[p - 1] + HI) + gammath
        den = kai11 * lam1 * (a[p - 1] - gammath * (Xi * sum_before + sum_after) - gammath * HI)

    return num / den


def P(alphaSD1, mSD1, BSD1, p, a, Ap_value, deltaSD1):
    user_OP_sum = 0
    for k in range(mSD1):
        theta = Theta(k, deltaSD1, mSD1)
        safe_input = np.clip(-Ap_value * BSD1, -700, 700)
        exp_term = np.exp(safe_input)
        factorial_k = math.factorial(k)
        first_term = factorial_k / (BSD1 ** (k + 1))
        second_term_sum = sum((factorial_k / math.factorial(n)) * (Ap_value ** n) / (BSD1 ** (k - n + 1)) for n in range(k + 1))
        user_OP = theta * (first_term - exp_term * second_term_sum)
        user_OP_sum += user_OP
    result = alphaSD1 * user_OP_sum
    return min(max(result, 0), 1)

def gammath_for_user(p, eta):
    if p == 1:
        return 1
    return eta * gammath_for_user(p - 1, eta)

def fitness_func_fixed(a, *args):
    M, alphaSD1, mSD1, BSD1, lam1, deltaSD1, kai11, V11, HI, Xi, eta = args
    mSD1 = int(mSD1)

    # --- Soft constraint check ---
    violates = False
    gammath1 = gammath_for_user(1, eta)
    if a[0] <= (np.sum(a[1:]) + HI) * gammath1:
        violates = True
    for p in range(1, M + 1):
        sum_before = np.sum(a[:p - 1])
        sum_after = np.sum(a[p:]) if p < M else 0
        if a[p - 1] <= (Xi * sum_before + sum_after + HI) * gammath_for_user(p, eta):
            violates = True
            break
    if violates:
        return 1.0 + 0.1  # soft penalty

    # --- OP computation ---
    total_OP = 1
    for p in range(1, M + 1):
        gammath_p = gammath_for_user(p, eta)
        try:
            Ap_value = Ap(M, gammath_p, kai11, V11, lam1, HI, Xi, p, a)
            Pp = P(alphaSD1, mSD1, BSD1, p, a, Ap_value, deltaSD1)
            total_OP *= max(1 - Pp, 1e-12)
        except Exception:
            return 1.0  # fallback on error
    return 1 - total_OP



def apply_constraints(particles, dimensions, Xi, HI, eta):
    gammath1 = gammath_for_user(1, eta)
    for i in range(particles.shape[0]):
        tries = 0
        while True:
            tries += 1
            valid = True
            if tries > 1000:
                break
            particles[i, :] = np.random.dirichlet(np.ones(dimensions), size=1)[0]
            particles[i, :] = np.sort(particles[i, :])[::-1]
            sum_a_i = np.sum(particles[i, 1:])
            if particles[i, 0] <= (sum_a_i + HI) * gammath1:
                valid = False
            for p in range(1, dimensions + 1):
                sum_before_p = np.sum(particles[i, :p - 1]) if p >= 2 else 0
                sum_after_p = np.sum(particles[i, p:]) if p < dimensions else 0
                if particles[i, p - 1] <= (Xi * sum_before_p + sum_after_p + HI) * gammath_for_user(p, eta):
                    valid = False
                    break
            if valid:
                break
    return particles

# ✅ 修改后的 pso 函数：返回收敛轨迹
def pso(fitness_func, bounds, num_particles, max_iter, method, *args, epsilon=5):  # 新增 epsilon 参数
    dim = len(bounds)
    np.random.seed(42)  # 保证可复现
    particles = np.random.uniform(bounds[:, 0], bounds[:, 1], (num_particles, dim))
    velocities = np.zeros((num_particles, dim))
    pbest_positions = particles.copy()
    pbest_values = np.array([fitness_func(p, *args) for p in particles])
    gbest_idx = np.argmin(pbest_values)
    gbest_position = particles[gbest_idx].copy()
    gbest_value = pbest_values[gbest_idx]
    gbest_value_per_iter = []

    w_start, w_end = 0.9, 0.4

    for current_iter in range(max_iter):
        # ✅ 使用指数衰减的惯性权重
        if method == 'SA-PSO':
            w = w_end + (w_start - w_end) * np.exp(-epsilon * current_iter / max_iter)
        else:
            w = 0.5

        for i in range(num_particles):
            r1, r2 = np.random.rand(2)
            velocities[i] = w * velocities[i] + 2.05 * r1 * (pbest_positions[i] - particles[i]) + 2.05 * r2 * (gbest_position - particles[i])
            particles[i] += velocities[i]
            # ✅ 不再 apply_constraints 强行重置

            val = fitness_func(particles[i], *args)
            if val < pbest_values[i]:
                pbest_positions[i] = particles[i].copy()
                pbest_values[i] = val
                if val < gbest_value:
                    gbest_position = particles[i].copy()
                    gbest_value = val
        gbest_value_per_iter.append(gbest_value)
    return gbest_value, gbest_value_per_iter








import matplotlib.pyplot as plt
import numpy as np
import matplotlib as mpl
from scipy.io import savemat

# 设置全局字体为 Times New Roman
mpl.rcParams['font.family'] = 'Times New Roman'
mpl.rcParams['font.size'] = 12
mpl.rcParams['mathtext.fontset'] = 'stix'

# 要测试的 ε（epsilon）列表
epsilon_list = [3, 4, 5, 6, 7]
num_particles = 50
max_iter = 100
iteration = np.arange(1, max_iter + 1)

# 场景设置
scenarios = [(4, 35)]  # 可以只跑一个 SNR 场景；如需跑多个可扩展

# 初始化绘图
plt.figure(figsize=(10, 6))
results_mat = {}
results_mat['iteration'] = iteration

for (M, snr_db) in scenarios:
    print(f"\n[INFO] Running sensitivity test for M={M}, SNR={snr_db} dB")

    params = initialize_parameters_fixed(M, snr_db)
    args = (M, *params)
    bounds = np.array([(0, 1) for _ in range(M)])

    # 测试不同 ε 的 SA-PSO
    for epsilon in epsilon_list:
        print(f"  → SA-PSO, ε = {epsilon}")
        val_sa, sa_curve = pso(fitness_func_fixed, bounds, num_particles, max_iter,
                               'SA-PSO', *args, epsilon=epsilon)
        sa_curve = np.where(np.isclose(sa_curve, 1.1), 1.0, sa_curve)  # 清理惩罚项
        label_str = fr'SA-PSO ($\varepsilon$={epsilon})'
        plt.semilogy(iteration, sa_curve, label=label_str, linewidth=2)
        results_mat[f'sa_eps{epsilon}_M{M}_SNR{snr_db}'] = np.array(sa_curve)

    # 运行一次 PSO 作为对比
    print(f"  → PSO baseline")
    val_pso, pso_curve = pso(fitness_func_fixed, bounds, num_particles, max_iter,
                             'PSO', *args)
    pso_curve = np.where(np.isclose(pso_curve, 1.1), 1.0, pso_curve)
    plt.semilogy(iteration, pso_curve, label=fr'PSO (baseline)', linestyle='--', linewidth=2)
    results_mat[f'pso_M{M}_SNR{snr_db}'] = np.array(pso_curve)

plt.xlabel('Iteration', fontsize=12)
plt.ylabel('System Outage Probability (OP)', fontsize=12)
plt.title(r'Convergence Comparison of SA-PSO under Different $\varepsilon$ Values (M=4)', fontsize=14)
plt.grid(True, linestyle='--', alpha=0.6)
plt.legend(fontsize=11, loc='upper right')
plt.tight_layout()
plt.savefig("sensitivity_epsilon_curve.pdf", dpi=300)
savemat("sensitivity_results.mat", results_mat)
plt.show()
print("✅ 图像保存为 sensitivity_epsilon_curve.pdf")
print("✅ 数据保存为 sensitivity_results.mat")
