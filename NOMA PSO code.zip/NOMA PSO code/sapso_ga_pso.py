import math
import numpy as np
import matplotlib.pyplot as plt
import sys
print(sys.executable)


def initialize_parameters_fixed(M, lam1_dB):
    mSD1 = int(5)
    bSD1 = 0.251
    omegaSD1 = 0.278
    alphaSD1 = ((2 * bSD1 * mSD1) / (2 * bSD1 * mSD1 + omegaSD1)) ** mSD1 / (2 * bSD1)
    betaSD1 = 1 / (2 * bSD1)
    deltaSD1 = omegaSD1 / (2 * bSD1 * (2 * bSD1 * mSD1 + omegaSD1))
    BSD1 = betaSD1 - deltaSD1
    kai11 = 0.5
    V11 = 0.001
    ks = 0.1
    kD1 = 0.1
    HI = ks ** 2 + kD1 ** 2
    Xi = 0.01
    lam1 = 10 ** (lam1_dB / 10)
    eta = 0.8
    return mSD1, alphaSD1, BSD1, lam1, deltaSD1, kai11, V11, HI, Xi, eta

def Pochhammer(s, k):
    result = 1
    for i in range(k):
        result *= (s + i)
    return result

def Theta(k, deltaSD1, mSD1):
    if k == 0:
        return 1
    return ((-1) ** k * Pochhammer(1 - mSD1, k) * deltaSD1 ** k) / (math.factorial(k) ** 2)

def Ap(M, gammath, kai11, V11, lam1, HI, Xi, p, a):
    sum_before = np.sum(a[:p - 1])  # safe: a[:0] is empty if p=1
    sum_after = np.sum(a[p:]) if p < M else 0  # avoid a[p] when p=M

    if p == 1:
        num = gammath * kai11 * V11 * lam1 * (1 + HI) + gammath
        den = kai11 * lam1 * (a[p - 1] - gammath * np.sum(a[1:]) - gammath * HI)
    else:
        num = gammath * kai11 * V11 * lam1 * (Xi * sum_before + sum_after + a[p - 1] + HI) + gammath
        den = kai11 * lam1 * (a[p - 1] - gammath * (Xi * sum_before + sum_after) - gammath * HI)

    return num / den


def P(alphaSD1, mSD1, BSD1, p, a, Ap_value, deltaSD1):
    user_OP_sum = 0
    for k in range(mSD1):
        theta = Theta(k, deltaSD1, mSD1)
        safe_input = np.clip(-Ap_value * BSD1, -700, 700)
        exp_term = np.exp(safe_input)
        factorial_k = math.factorial(k)
        first_term = factorial_k / (BSD1 ** (k + 1))
        second_term_sum = sum((factorial_k / math.factorial(n)) * (Ap_value ** n) / (BSD1 ** (k - n + 1)) for n in range(k + 1))
        user_OP = theta * (first_term - exp_term * second_term_sum)
        user_OP_sum += user_OP
    result = alphaSD1 * user_OP_sum
    return min(max(result, 0), 1)

def gammath_for_user(p, eta):
    if p == 1:
        return 1
    return eta * gammath_for_user(p - 1, eta)

def fitness_func_fixed(a, *args):
    M, alphaSD1, mSD1, BSD1, lam1, deltaSD1, kai11, V11, HI, Xi, eta = args
    mSD1 = int(mSD1)

    # --- Soft constraint check ---
    violates = False
    gammath1 = gammath_for_user(1, eta)
    if a[0] <= (np.sum(a[1:]) + HI) * gammath1:
        violates = True
    for p in range(1, M + 1):
        sum_before = np.sum(a[:p - 1])
        sum_after = np.sum(a[p:]) if p < M else 0
        if a[p - 1] <= (Xi * sum_before + sum_after + HI) * gammath_for_user(p, eta):
            violates = True
            break
    if violates:
        return 1.0 + 0.1  # soft penalty

    # --- OP computation ---
    total_OP = 1
    for p in range(1, M + 1):
        gammath_p = gammath_for_user(p, eta)
        try:
            Ap_value = Ap(M, gammath_p, kai11, V11, lam1, HI, Xi, p, a)
            Pp = P(alphaSD1, mSD1, BSD1, p, a, Ap_value, deltaSD1)
            total_OP *= max(1 - Pp, 1e-12)
        except Exception:
            return 1.0  # fallback on error
    return 1 - total_OP



def apply_constraints(particles, dimensions, Xi, HI, eta):
    gammath1 = gammath_for_user(1, eta)
    for i in range(particles.shape[0]):
        tries = 0
        while True:
            tries += 1
            valid = True
            if tries > 1000:
                break
            particles[i, :] = np.random.dirichlet(np.ones(dimensions), size=1)[0]
            particles[i, :] = np.sort(particles[i, :])[::-1]
            sum_a_i = np.sum(particles[i, 1:])
            if particles[i, 0] <= (sum_a_i + HI) * gammath1:
                valid = False
            for p in range(1, dimensions + 1):
                sum_before_p = np.sum(particles[i, :p - 1]) if p >= 2 else 0
                sum_after_p = np.sum(particles[i, p:]) if p < dimensions else 0
                if particles[i, p - 1] <= (Xi * sum_before_p + sum_after_p + HI) * gammath_for_user(p, eta):
                    valid = False
                    break
            if valid:
                break
    return particles

# ✅ 修改后的 pso 函数：返回收敛轨迹
def pso(fitness_func, bounds, num_particles, max_iter, method, *args):
    dim = len(bounds)
    np.random.seed(42)  # 保证可复现
    particles = np.random.uniform(bounds[:, 0], bounds[:, 1], (num_particles, dim))
    velocities = np.zeros((num_particles, dim))
    pbest_positions = particles.copy()
    pbest_values = np.array([fitness_func(p, *args) for p in particles])
    gbest_idx = np.argmin(pbest_values)
    gbest_position = particles[gbest_idx].copy()
    gbest_value = pbest_values[gbest_idx]
    gbest_value_per_iter = []

    w_start, w_end = 0.9, 0.4

    for current_iter in range(max_iter):
        # ✅ Exponential decay inertia weight
        w = w_end + (w_start - w_end) * np.exp(-5 * current_iter / max_iter) if method == 'SA-PSO' else 0.5

        for i in range(num_particles):
            r1, r2 = np.random.rand(2)
            velocities[i] = w * velocities[i] + 2.05 * r1 * (pbest_positions[i] - particles[i]) + 2.05 * r2 * (gbest_position - particles[i])
            particles[i] += velocities[i]
            # ✅ 不再 apply_constraints 强行重置

            val = fitness_func(particles[i], *args)
            if val < pbest_values[i]:
                pbest_positions[i] = particles[i].copy()
                pbest_values[i] = val
                if val < gbest_value:
                    gbest_position = particles[i].copy()
                    gbest_value = val
        gbest_value_per_iter.append(gbest_value)
    return gbest_value, gbest_value_per_iter

#遗传算法
def ga(fitness_func, bounds, pop_size, max_gen, *args):
    dim = len(bounds)
    mutation_rate = 0.1
    crossover_rate = 0.8
    elitism_rate = 0.1
    elite_count = int(pop_size * elitism_rate)

    # 解构约束参数（倒数第三、第二、第一项）
    Xi, HI, eta = args[-3], args[-2], args[-1]

    # 初始化种群（使用约束修正）
    population = apply_constraints(np.random.rand(pop_size, dim), dim, Xi, HI, eta)
    fitness = np.array([fitness_func(ind, *args) for ind in population])
    print("Initial fitness (GA):", fitness[:10])

    best_fitness_per_gen = []

    for gen in range(max_gen):
        # === 精英保留 ===
        elite_indices = np.argsort(fitness)[:elite_count]
        elites = population[elite_indices]

        # === 轮盘赌选择（防止 NaN） ===
        inverse_fitness = 1.1 - fitness
        total_inv = np.sum(inverse_fitness)
        if total_inv == 0 or np.isnan(total_inv):
            selection_probs = np.ones(pop_size) / pop_size
        else:
            selection_probs = inverse_fitness / total_inv

        # 父代数量（偶数）
        num_parents = pop_size - elite_count
        if num_parents % 2 != 0:
            num_parents -= 1

        parents_indices = np.random.choice(pop_size, size=num_parents, p=selection_probs)
        parents = population[parents_indices]

        # === 交叉 ===
        offspring = []
        i = 0
        while i + 1 < len(parents):
            p1, p2 = parents[i], parents[i + 1]
            if np.random.rand() < crossover_rate:
                point = np.random.randint(1, dim)
                child1 = np.concatenate((p1[:point], p2[point:]))
                child2 = np.concatenate((p2[:point], p1[point:]))
                offspring.extend([child1, child2])
            else:
                offspring.extend([p1, p2])
            i += 2

        # === 变异 ===
        for i in range(len(offspring)):
            if np.random.rand() < mutation_rate:
                idx = np.random.randint(dim)
                mutation = np.random.uniform(0, 1)
                offspring[i][idx] = mutation
                offspring[i] = np.sort(offspring[i])[::-1]
                offspring[i] /= np.sum(offspring[i])  # 保持归一化

        # === 构造新一代（防止数量不够） ===
        num_offspring_needed = pop_size - elite_count
        if len(offspring) < num_offspring_needed:
            additional = [offspring[i % len(offspring)] for i in range(num_offspring_needed - len(offspring))]
            offspring.extend(additional)
        new_population = np.vstack((elites, offspring[:num_offspring_needed]))

        # 替代种群并重新计算适应度
        population = apply_constraints(new_population, dim, Xi, HI, eta)
        fitness = np.array([fitness_func(ind, *args) for ind in population])
        best_fitness_per_gen.append(np.min(fitness))

    best_idx = np.argmin(fitness)
    return fitness[best_idx], best_fitness_per_gen







import matplotlib.pyplot as plt
import numpy as np
import matplotlib as mpl
from scipy.io import savemat

# 设置全局字体为 Times New Roman
mpl.rcParams['font.family'] = 'Times New Roman'
mpl.rcParams['font.size'] = 12
mpl.rcParams['mathtext.fontset'] = 'stix'

# 场景设定
scenarios = [(4, 35), (4, 45), (4, 55)]
num_particles = 50
max_iter = 60

# 配色与标记
color_map = {35: 'red', 45: 'black', 55: 'blue'}
marker_map = {35: '^', 45: 'o', 55: 's'}

# 存储所有数据以便导出 .mat
results_mat = {}
iteration = np.arange(1, max_iter + 1)
results_mat['iteration'] = iteration

# 绘图准备
plt.figure(figsize=(10, 6))

# 主循环
for (M, snr_db) in scenarios:
    print(f"\n[INFO] Running for M={M}, SNR={snr_db} dB")

    params = initialize_parameters_fixed(M, snr_db)
    args = (M, *params)
    bounds = np.array([(0, 1) for _ in range(M)])

    val_sa, sa_curve = pso(fitness_func_fixed, bounds, num_particles, max_iter, 'SA-PSO', *args)
    val_pso, pso_curve = pso(fitness_func_fixed, bounds, num_particles, max_iter, 'PSO', *args)


    val_ga, ga_curve = ga(fitness_func_fixed, bounds, num_particles, max_iter, *args)


    # 替换所有值为 1.1 → 1（用于消除惩罚项）
    sa_curve = np.where(np.isclose(sa_curve, 1.1), 1.0, sa_curve)
    pso_curve = np.where(np.isclose(pso_curve, 1.1), 1.0, pso_curve)

    ga_curve = np.where(np.isclose(ga_curve, 1.1), 1.0, ga_curve)
    print(f"  GA     Final OP: {val_ga:.4e}")
    print(f"  SA-PSO Final OP: {val_sa:.4e}")
    print(f"  PSO    Final OP: {val_pso:.4e}")

    # 绘图
    color = color_map[snr_db]
    marker = marker_map[snr_db]

    plt.semilogy(iteration, sa_curve, label=fr'SA-PSO  ($\mu$SNR={snr_db}dB)',
                 color=color, marker=marker, linestyle='-', linewidth=2, markersize=6)

    plt.semilogy(iteration, pso_curve, label=fr'PSO     ($\mu$SNR={snr_db}dB)',
                 color=color, marker=marker, linestyle='--', linewidth=2, markersize=6)
    plt.semilogy(iteration, ga_curve, label=fr'GA      ($\mu$SNR={snr_db}dB)',
                 color=color, marker=marker, linestyle='-.', linewidth=2, markersize=6)



    # 保存数据
    results_mat[f'sa3_M{M}_SNR{snr_db}'] = np.array(sa_curve)
    results_mat[f'pso3_M{M}_SNR{snr_db}'] = np.array(pso_curve)

    results_mat[f'ga3_M{M}_SNR{snr_db}'] = np.array(ga_curve)

# 图形设置
plt.xlabel('Iteration', fontsize=12, fontname='Times New Roman')
plt.ylabel('System Outage Probability (OP)', fontsize=12, fontname='Times New Roman')
plt.title('Convergence of SA-PSO vs PSO vs GA under Different $\mu$SNRs (M=4)', fontsize=14, fontname='Times New Roman')
plt.xticks(fontname='Times New Roman', fontsize=12)
plt.yticks(fontname='Times New Roman', fontsize=12)
plt.grid(True, linestyle='--', alpha=0.6)
plt.legend(fontsize=12, loc='upper right', frameon=True)
plt.tight_layout()

# 保存图像和 .mat 文件
#plt.savefig("combined_convergence_curve.pdf", dpi=300)
savemat("sapso_ga_pso_convergence.mat", results_mat)
#print("✅ 图像保存为 combined_convergence_curve.pdf")
print("✅ 数据保存为 sapso_ga_pso_convergence.mat")
plt.show()
