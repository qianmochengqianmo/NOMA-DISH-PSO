import math
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl

mpl.rcParams['mathtext.fontset'] = 'stix'  # 使用 Times 字体渲染数学公式
mpl.rcParams['font.family'] = 'Times New Roman'  # 全局字体设置为 Times New Roman

# 初始化参数
def initialize_parameters(M):
    mSD1 = 5
    bSD1 = 0.251
    omegaSD1 = 0.278
    alphaSD1 = ((2 * bSD1 * mSD1) / (2 * bSD1 * mSD1 + omegaSD1)) ** mSD1 / (2 * bSD1)
    betaSD1 = 1 / (2 * bSD1)
    deltaSD1 = omegaSD1 / (2 * bSD1 * (2 * bSD1 * mSD1 + omegaSD1))
    BSD1 = betaSD1 - deltaSD1
    kai11 = 0.5
    V11 = 0.001
    ks = 0.1
    kD1 = 0.1
    HI = ks ** 2 + kD1 ** 2
    Xi = 0.01
    lam1 = 10 ** (35/ 10)
    eta = 0.6 # 固定阈值比率

    return mSD1, alphaSD1, BSD1, lam1, deltaSD1,  kai11, V11, HI, Xi, eta

def Pochhammer(s, k):
    result = 1
    for i in range(k):
        result *= (s + i)
    return result

def Theta(k, deltaSD1, mSD1):
    if k == 0:
        return 1  # 对于 k=0, Theta应该为1
    return ((-1) ** k * Pochhammer(1 - mSD1, k) * deltaSD1 ** k) / (math.factorial(k) ** 2)

def Ap(M, gammath, kai11, V11, lam1, HI, Xi, p, a):
    if p == 1:
        num = gammath * kai11 * V11 * lam1 * (1 + HI) + gammath
        den = kai11 * lam1 * (a[p - 1] - gammath * np.sum(a[1:]) - gammath * HI)
    else:
        num = gammath * kai11 * V11 * lam1 * (Xi * np.sum(a[:p - 1]) + np.sum(a[p:]) + a[p - 1] + HI) + gammath
        den = kai11 * lam1 * (a[p - 1] - gammath * (Xi * np.sum(a[:p - 1]) + np.sum(a[p:])) - gammath * HI)

    Ap_value = num / den
    return Ap_value

# 计算单个用户的 P
def P(alphaSD1, mSD1, BSD1, deltaSD1, p, a, Ap_value):
    user_OP_sum = 0
    for k in range(mSD1):
        theta = Theta(k, deltaSD1, mSD1)
        exp_term = np.exp(-Ap_value * BSD1)
        factorial_k = math.factorial(k)
        first_term = factorial_k / (BSD1 ** (k + 1))
        second_term_sum = 0
        for n in range(k + 1):
            second_term_sum += (factorial_k / math.factorial(n)) * (Ap_value ** n) / (BSD1 ** (k - n + 1))
        user_OP = theta * (first_term - exp_term * second_term_sum)
        user_OP_sum += user_OP
    return alphaSD1 * user_OP_sum

# 计算阈值gammath
def gammath_for_user(p, eta):
    if p == 1:
        return 1# 用户1的固定阈值
    else:
        return eta * gammath_for_user(p - 1, eta)  # 递归计算其他用户的阈值

def fitness_func(a, *args):
    M, alphaSD1, mSD1, BSD1, lam1, deltaSD1, kai11, V11, HI, Xi, eta = args
    total_OP = 1
    user_OPs = []
    gammaths = []

    # 为每个用户计算gammath
    for p in range(1, M + 1):
        gammath_p = gammath_for_user(p, eta)
        gammaths.append(gammath_p)

    # 计算总中断概率
    for p in range(1, M + 1):
        Ap_value = Ap(M, gammaths[p - 1], kai11, V11, lam1, HI, Xi, p, a)
        Pp = P(alphaSD1, mSD1, BSD1, deltaSD1, p, a, Ap_value)
        user_OPs.append(Pp)

    for Pp in user_OPs:
        total_OP *= (1 - Pp)

    return 1 - total_OP, gammaths

def apply_constraints(particles, dimensions, Xi, HI, eta):
    if isinstance(particles, list):
        particles = np.array(particles)
    gammath1 = gammath_for_user(1, eta)
    for i in range(particles.shape[0]):
        while True:
            valid = True
            particles[i, :] = np.random.dirichlet(np.ones(dimensions), size=1)[0]
            particles[i, :] = np.sort(particles[i, :])[::-1]

            sum_a_i = np.sum(particles[i, 1:])
            constraint_value1 = (sum_a_i + HI) * gammath1
            if particles[i, 0] <= constraint_value1:
                valid = False

            for p in range(1, dimensions + 1):
                sum_before_p = np.sum(particles[i, :p - 1]) if p >= 2 else 0
                sum_after_p = np.sum(particles[i, p:]) if p < dimensions else 0
                gammath_p = gammath_for_user(p, eta)
                constraint_value2 = (Xi * sum_before_p + sum_after_p + HI) * gammath_p
                if particles[i, p - 1] <= constraint_value2:
                    valid = False
                    break

            if valid:
                break
    return particles

# PSO算法
def pso(fitness_func, bounds, num_particles, max_iter, *args):
    dim = len(bounds)  # 维度
    particles = np.random.uniform(bounds[:, 0], bounds[:, 1], (num_particles, dim))  # 初始化粒子位置
    velocities = np.zeros((num_particles, dim))  # 初始化粒子速度

    # 初始化最佳位置
    pbest_positions = particles.copy()
    particles = apply_constraints(particles, dim, args[9], args[8], args[10])  # 应用约束确保初始状态符合要求

    pbest_values = []
    for particle in particles:
        fitness_value, gammaths = fitness_func(particle, *args)
        pbest_values.append((fitness_value, gammaths))

    gbest_value, gbest_gammaths = min(pbest_values, key=lambda x: x[0])
    gbest_position = particles[pbest_values.index((gbest_value, gbest_gammaths))]

    w_start = 0.9
    w_end = 0.3

    # 记录适应度值
    best_fitness_values = []
    average_fitness_values = []

    # 迭代
    for current_iter in range(max_iter):
        #w = w_start - (w_start - w_end) * (current_iter / max_iter) #SA-PSO
        w = 0.5 #PSO
        for i in range(num_particles):
            # 更新速度
            r1, r2 = np.random.rand(2)
            velocities[i] = w * velocities[i] + 2.05 * r1 * (pbest_positions[i] - particles[i]) + 2.05 * r2 * (
                    gbest_position - particles[i])

            # 更新位置
            particles[i] += velocities[i]

            # 应用约束和边界条件
            particles = apply_constraints(particles, dim, args[9], args[8], args[10])

            # 检查每个粒子是否满足约束条件
            for j in range(particles.shape[0]):
                particles[j, :] = apply_constraints([particles[j, :]], dim, args[9], args[8], args[10])[0]

            # 更新最佳位置
            current_value, current_gammaths = fitness_func(particles[i], *args)
            if current_value < pbest_values[i][0]:
                pbest_positions[i] = particles[i].copy()
                pbest_values[i] = (current_value, current_gammaths)

            # 更新全局最佳位置
            if current_value < gbest_value:
                gbest_value = current_value
                gbest_position = particles[i].copy()
                gbest_gammaths = current_gammaths

        # 记录当前迭代的最佳适应度和平均适应度
        best_fitness_values.append(gbest_value)
        avg_fitness = np.mean([val[0] for val in pbest_values])
        average_fitness_values.append(avg_fitness)

    return gbest_position, gbest_value, gbest_gammaths, best_fitness_values, average_fitness_values

def run_pso_with_different_users(user_counts, num_particles, max_iter):
    results = {}
    for M in user_counts:
        # 初始化参数
        mSD1, alphaSD1, BSD1, lam1, deltaSD1, kai11, V11, HI, Xi, eta = initialize_parameters(M)
        bounds = np.array([(0, 1) for _ in range(M)])
        args = (M, alphaSD1, mSD1, BSD1, lam1, deltaSD1, kai11, V11, HI, Xi, eta)
        # 执行PSO算法并记录适应度值
        best_position, best_value, best_gammath, best_fitness_values, average_fitness_values = pso(fitness_func, bounds, num_particles, max_iter, *args)
        results[M] = (best_fitness_values, average_fitness_values)
    return results

# 设置不同用户数量，运行PSO算法
user_counts = [3, 5, 8]  # 可以根据需要增加用户数量
num_particles = 30
max_iter = 61
results = run_pso_with_different_users(user_counts, num_particles, max_iter)
# Plotting
plt.figure(figsize=(6, 4.5))
for M, (best_fitness_values, average_fitness_values) in results.items():
    plt.semilogy(best_fitness_values, label=f'Best Fitness ($M={M}$)', marker='o')
    plt.semilogy(average_fitness_values, label=f'Average Fitness ($M={M}$)', marker='x')

# Set font properties
plt.xlabel('Iterations', fontsize=12, fontname='Times New Roman')
plt.ylabel('Fitness Value', fontsize=12, fontname='Times New Roman')
plt.xticks(fontsize=12, fontname='Times New Roman')
plt.yticks(fontsize=12, fontname='Times New Roman')

# Set legend font properties
leg = plt.legend(fontsize=12, loc='upper right')
for text in leg.get_texts():
    text.set_fontname("Times New Roman")
    text.set_fontsize(12)

plt.grid(True)
plt.xlim(0, 60)
plt.ylim(1e-2, 1e-1 + 0.05)

plt.savefig('fitness_plot.eps', format='eps', dpi=1000, bbox_inches='tight')
plt.show()

